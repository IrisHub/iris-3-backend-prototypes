import boto3 
from datetime import datetime
from datetime import timedelta

def event_handler(event, context):
	user_id = event['user_id']
	friend_ids = event['friend_ids']
	acquaintance_ids = event['acquaintance_ids']

	filt = lambda s: "".join(filter(str.isdigit, s))[-10:]
	user_id = filt(user_id)
	friend_ids = [filt(f) for f in friend_ids]
	acquaintance_ids = [filt(a) for a in acquaintance_ids]

	dynamodb = boto3.resource('dynamodb')
	table = dynamodb.Table('contacts_experiments_2')

	table.put_item(
		Item = {
			'user_id':user_id,
			'friend_ids':friend_ids,
			'acquaintance_ids':acquaintance_ids,
			'last_refreshed':(datetime.today()-timedelta(hours=7)-timedelta(7+((datetime.today().weekday()+1) % 7)-6)).strftime('%Y-%m-%d'),
			'current_contacts':{}
		})


def __main__():
	event_handler({
		'user_id':"12324565",
		'friend_ids':['1223','34634','23423'],
		'acquaintance_ids':['6245545','345265','134546','2346252643']
		}, None)

__main__()